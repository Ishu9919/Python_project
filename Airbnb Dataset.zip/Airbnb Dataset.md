```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
```


```python
df=pd.read_csv(r'C:\Users\Ishwar Chandra\Documents\CSV file\Airbnb NYC 2019.csv')
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>name</th>
      <th>host_id</th>
      <th>host_name</th>
      <th>neighbourhood_group</th>
      <th>neighbourhood</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>room_type</th>
      <th>price</th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>last_review</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2539</td>
      <td>Clean &amp; quiet apt home by the park</td>
      <td>2787</td>
      <td>John</td>
      <td>Brooklyn</td>
      <td>Kensington</td>
      <td>40.64749</td>
      <td>-73.97237</td>
      <td>Private room</td>
      <td>149</td>
      <td>1</td>
      <td>9</td>
      <td>2018-10-19</td>
      <td>0.21</td>
      <td>6</td>
      <td>365</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2595</td>
      <td>Skylit Midtown Castle</td>
      <td>2845</td>
      <td>Jennifer</td>
      <td>Manhattan</td>
      <td>Midtown</td>
      <td>40.75362</td>
      <td>-73.98377</td>
      <td>Entire home/apt</td>
      <td>225</td>
      <td>1</td>
      <td>45</td>
      <td>2019-05-21</td>
      <td>0.38</td>
      <td>2</td>
      <td>355</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3647</td>
      <td>THE VILLAGE OF HARLEM....NEW YORK !</td>
      <td>4632</td>
      <td>Elisabeth</td>
      <td>Manhattan</td>
      <td>Harlem</td>
      <td>40.80902</td>
      <td>-73.94190</td>
      <td>Private room</td>
      <td>150</td>
      <td>3</td>
      <td>0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>365</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3831</td>
      <td>Cozy Entire Floor of Brownstone</td>
      <td>4869</td>
      <td>LisaRoxanne</td>
      <td>Brooklyn</td>
      <td>Clinton Hill</td>
      <td>40.68514</td>
      <td>-73.95976</td>
      <td>Entire home/apt</td>
      <td>89</td>
      <td>1</td>
      <td>270</td>
      <td>2019-07-05</td>
      <td>4.64</td>
      <td>1</td>
      <td>194</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5022</td>
      <td>Entire Apt: Spacious Studio/Loft by central park</td>
      <td>7192</td>
      <td>Laura</td>
      <td>Manhattan</td>
      <td>East Harlem</td>
      <td>40.79851</td>
      <td>-73.94399</td>
      <td>Entire home/apt</td>
      <td>80</td>
      <td>10</td>
      <td>9</td>
      <td>2018-11-19</td>
      <td>0.10</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.shape
```




    (48895, 16)




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 48895 entries, 0 to 48894
    Data columns (total 16 columns):
     #   Column                          Non-Null Count  Dtype  
    ---  ------                          --------------  -----  
     0   id                              48895 non-null  int64  
     1   name                            48879 non-null  object 
     2   host_id                         48895 non-null  int64  
     3   host_name                       48874 non-null  object 
     4   neighbourhood_group             48895 non-null  object 
     5   neighbourhood                   48895 non-null  object 
     6   latitude                        48895 non-null  float64
     7   longitude                       48895 non-null  float64
     8   room_type                       48895 non-null  object 
     9   price                           48895 non-null  int64  
     10  minimum_nights                  48895 non-null  int64  
     11  number_of_reviews               48895 non-null  int64  
     12  last_review                     38843 non-null  object 
     13  reviews_per_month               38843 non-null  float64
     14  calculated_host_listings_count  48895 non-null  int64  
     15  availability_365                48895 non-null  int64  
    dtypes: float64(3), int64(7), object(6)
    memory usage: 6.0+ MB
    


```python
df.isnull().sum()
```




    id                                    0
    name                                 16
    host_id                               0
    host_name                            21
    neighbourhood_group                   0
    neighbourhood                         0
    latitude                              0
    longitude                             0
    room_type                             0
    price                                 0
    minimum_nights                        0
    number_of_reviews                     0
    last_review                       10052
    reviews_per_month                 10052
    calculated_host_listings_count        0
    availability_365                      0
    dtype: int64




```python
df.fillna({'reviews_per_month':0},inplace=True)
```


```python
df.isnull().sum()
```




    id                                    0
    name                                 16
    host_id                               0
    host_name                            21
    neighbourhood_group                   0
    neighbourhood                         0
    latitude                              0
    longitude                             0
    room_type                             0
    price                                 0
    minimum_nights                        0
    number_of_reviews                     0
    last_review                       10052
    reviews_per_month                     0
    calculated_host_listings_count        0
    availability_365                      0
    dtype: int64




```python
df.columns
```




    Index(['id', 'name', 'host_id', 'host_name', 'neighbourhood_group',
           'neighbourhood', 'latitude', 'longitude', 'room_type', 'price',
           'minimum_nights', 'number_of_reviews', 'last_review',
           'reviews_per_month', 'calculated_host_listings_count',
           'availability_365'],
          dtype='object')




```python
graph_1=df.groupby(['neighbourhood_group'],as_index=False)['price'].mean().sort_values(['price'],ascending=False)
```


```python
graph_1
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>neighbourhood_group</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>Manhattan</td>
      <td>196.875814</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Brooklyn</td>
      <td>124.383207</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Staten Island</td>
      <td>114.812332</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Queens</td>
      <td>99.517649</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Bronx</td>
      <td>87.496792</td>
    </tr>
  </tbody>
</table>
</div>




```python
ax=sns.barplot(x='neighbourhood_group',y='price',data=graph_1)
plt.xlabel('location of Hotel',fontweight='bold')
plt.ylabel('Average Price',fontweight='bold')
for bar in ax.containers:
    ax.bar_label(bar)
plt.show()
```


    
![png](output_11_0.png)
    


we can see above from graph that in manhattan , most of hotel room booking.Comprare to other location.and second brooklyn


```python
df['neighbourhood_group'].value_counts()
```




    Manhattan        21661
    Brooklyn         20104
    Queens            5666
    Bronx             1091
    Staten Island      373
    Name: neighbourhood_group, dtype: int64




```python
filter_row=df[df['neighbourhood_group']=='Manhattan']
```


```python
filter_row.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>name</th>
      <th>host_id</th>
      <th>host_name</th>
      <th>neighbourhood_group</th>
      <th>neighbourhood</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>room_type</th>
      <th>price</th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>last_review</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>2595</td>
      <td>Skylit Midtown Castle</td>
      <td>2845</td>
      <td>Jennifer</td>
      <td>Manhattan</td>
      <td>Midtown</td>
      <td>40.75362</td>
      <td>-73.98377</td>
      <td>Entire home/apt</td>
      <td>225</td>
      <td>1</td>
      <td>45</td>
      <td>2019-05-21</td>
      <td>0.38</td>
      <td>2</td>
      <td>355</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3647</td>
      <td>THE VILLAGE OF HARLEM....NEW YORK !</td>
      <td>4632</td>
      <td>Elisabeth</td>
      <td>Manhattan</td>
      <td>Harlem</td>
      <td>40.80902</td>
      <td>-73.94190</td>
      <td>Private room</td>
      <td>150</td>
      <td>3</td>
      <td>0</td>
      <td>NaN</td>
      <td>0.00</td>
      <td>1</td>
      <td>365</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5022</td>
      <td>Entire Apt: Spacious Studio/Loft by central park</td>
      <td>7192</td>
      <td>Laura</td>
      <td>Manhattan</td>
      <td>East Harlem</td>
      <td>40.79851</td>
      <td>-73.94399</td>
      <td>Entire home/apt</td>
      <td>80</td>
      <td>10</td>
      <td>9</td>
      <td>2018-11-19</td>
      <td>0.10</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>5099</td>
      <td>Large Cozy 1 BR Apartment In Midtown East</td>
      <td>7322</td>
      <td>Chris</td>
      <td>Manhattan</td>
      <td>Murray Hill</td>
      <td>40.74767</td>
      <td>-73.97500</td>
      <td>Entire home/apt</td>
      <td>200</td>
      <td>3</td>
      <td>74</td>
      <td>2019-06-22</td>
      <td>0.59</td>
      <td>1</td>
      <td>129</td>
    </tr>
    <tr>
      <th>7</th>
      <td>5178</td>
      <td>Large Furnished Room Near B'way</td>
      <td>8967</td>
      <td>Shunichi</td>
      <td>Manhattan</td>
      <td>Hell's Kitchen</td>
      <td>40.76489</td>
      <td>-73.98493</td>
      <td>Private room</td>
      <td>79</td>
      <td>2</td>
      <td>430</td>
      <td>2019-06-24</td>
      <td>3.47</td>
      <td>1</td>
      <td>220</td>
    </tr>
  </tbody>
</table>
</div>




```python
minimum_nt=df.groupby(['neighbourhood_group'],as_index=False)['minimum_nights'].sum().sort_values(['minimum_nights'],ascending=False)
```


```python
minimum_nt
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>neighbourhood_group</th>
      <th>minimum_nights</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>2</th>
      <td>Manhattan</td>
      <td>185833</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Brooklyn</td>
      <td>121761</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Queens</td>
      <td>29358</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Bronx</td>
      <td>4976</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Staten Island</td>
      <td>1802</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.barplot(x='neighbourhood_group',y='minimum_nights',data=minimum_nt)
plt.xlabel('neighbourhood_group',fontweight='bold')
plt.ylabel('minimum_nights',fontweight='bold')
plt.show()
```


    
![png](output_18_0.png)
    



```python
#from above graph we can see that people maximum night spend or stay in manhattan.second position brooklyn
```


```python
pichart=df.groupby(['neighbourhood_group'],as_index=False)['number_of_reviews'].sum().sort_values(['number_of_reviews'],ascending=False)
```


```python
pichart
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>neighbourhood_group</th>
      <th>number_of_reviews</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>Brooklyn</td>
      <td>486574</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Manhattan</td>
      <td>454569</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Queens</td>
      <td>156950</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Bronx</td>
      <td>28371</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Staten Island</td>
      <td>11541</td>
    </tr>
  </tbody>
</table>
</div>




```python
ax=sns.barplot(x='neighbourhood_group',y='number_of_reviews',data=pichart)
for bar in ax.containers:
    ax.bar_label(bar)
    plt.xlabel('neighbourhood_group',fontweight='bold')
    plt.ylabel('number_of_reviews',fontweight='bold')
plt.show()
```


    
![png](output_22_0.png)
    



```python
# from above graph we can see that most of number_review get from brooklyn.and second position in review manhattan.
```


```python
room_ty=df.groupby(['room_type'],as_index=False)[['price']].mean()
```


```python
room_ty
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>room_type</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Entire home/apt</td>
      <td>211.794246</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Private room</td>
      <td>89.780973</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Shared room</td>
      <td>70.127586</td>
    </tr>
  </tbody>
</table>
</div>




```python
ax=sns.barplot(x='room_type',y='price',data=room_ty)
for bar in ax.containers:
    ax.bar_label(bar)
    plt.xlabel('room_type',fontweight='bold')
    plt.ylabel('price',fontweight='bold')
plt.show()
```


    
![png](output_26_0.png)
    



```python
#from above graph we can see that most the room booking in Entire home/apt.
```


```python
df.groupby(['room_type','neighbourhood_group'],as_index=False)[['price']].mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>room_type</th>
      <th>neighbourhood_group</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Entire home/apt</td>
      <td>Bronx</td>
      <td>127.506596</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Entire home/apt</td>
      <td>Brooklyn</td>
      <td>178.327545</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Entire home/apt</td>
      <td>Manhattan</td>
      <td>249.239109</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Entire home/apt</td>
      <td>Queens</td>
      <td>147.050573</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Entire home/apt</td>
      <td>Staten Island</td>
      <td>173.846591</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Private room</td>
      <td>Bronx</td>
      <td>66.788344</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Private room</td>
      <td>Brooklyn</td>
      <td>76.500099</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Private room</td>
      <td>Manhattan</td>
      <td>116.776622</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Private room</td>
      <td>Queens</td>
      <td>71.762456</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Private room</td>
      <td>Staten Island</td>
      <td>62.292553</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Shared room</td>
      <td>Bronx</td>
      <td>59.800000</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Shared room</td>
      <td>Brooklyn</td>
      <td>50.527845</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Shared room</td>
      <td>Manhattan</td>
      <td>88.977083</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Shared room</td>
      <td>Queens</td>
      <td>69.020202</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Shared room</td>
      <td>Staten Island</td>
      <td>57.444444</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.groupby(['neighbourhood_group','room_type'],as_index=False)[['price']].mean()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>neighbourhood_group</th>
      <th>room_type</th>
      <th>price</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Bronx</td>
      <td>Entire home/apt</td>
      <td>127.506596</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Bronx</td>
      <td>Private room</td>
      <td>66.788344</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Bronx</td>
      <td>Shared room</td>
      <td>59.800000</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Brooklyn</td>
      <td>Entire home/apt</td>
      <td>178.327545</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Brooklyn</td>
      <td>Private room</td>
      <td>76.500099</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Brooklyn</td>
      <td>Shared room</td>
      <td>50.527845</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Manhattan</td>
      <td>Entire home/apt</td>
      <td>249.239109</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Manhattan</td>
      <td>Private room</td>
      <td>116.776622</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Manhattan</td>
      <td>Shared room</td>
      <td>88.977083</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Queens</td>
      <td>Entire home/apt</td>
      <td>147.050573</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Queens</td>
      <td>Private room</td>
      <td>71.762456</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Queens</td>
      <td>Shared room</td>
      <td>69.020202</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Staten Island</td>
      <td>Entire home/apt</td>
      <td>173.846591</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Staten Island</td>
      <td>Private room</td>
      <td>62.292553</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Staten Island</td>
      <td>Shared room</td>
      <td>57.444444</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.set(rc={'figure.figsize':(15,5)})
sns.barplot(x='neighbourhood_group',y='price',data=df,hue='room_type')
plt.xlabel('neighbourhood_group',fontweight='bold')
plt.ylabel('price',fontweight='bold')
plt.show()
```


    
![png](output_30_0.png)
    



```python
#we can see from above graph,most of room booking in manhattan but Entire home/apt is greater booking from Private room and Share room booking.
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>name</th>
      <th>host_id</th>
      <th>host_name</th>
      <th>neighbourhood_group</th>
      <th>neighbourhood</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>room_type</th>
      <th>price</th>
      <th>minimum_nights</th>
      <th>number_of_reviews</th>
      <th>last_review</th>
      <th>reviews_per_month</th>
      <th>calculated_host_listings_count</th>
      <th>availability_365</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>2539</td>
      <td>Clean &amp; quiet apt home by the park</td>
      <td>2787</td>
      <td>John</td>
      <td>Brooklyn</td>
      <td>Kensington</td>
      <td>40.64749</td>
      <td>-73.97237</td>
      <td>Private room</td>
      <td>149</td>
      <td>1</td>
      <td>9</td>
      <td>2018-10-19</td>
      <td>0.21</td>
      <td>6</td>
      <td>365</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2595</td>
      <td>Skylit Midtown Castle</td>
      <td>2845</td>
      <td>Jennifer</td>
      <td>Manhattan</td>
      <td>Midtown</td>
      <td>40.75362</td>
      <td>-73.98377</td>
      <td>Entire home/apt</td>
      <td>225</td>
      <td>1</td>
      <td>45</td>
      <td>2019-05-21</td>
      <td>0.38</td>
      <td>2</td>
      <td>355</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3647</td>
      <td>THE VILLAGE OF HARLEM....NEW YORK !</td>
      <td>4632</td>
      <td>Elisabeth</td>
      <td>Manhattan</td>
      <td>Harlem</td>
      <td>40.80902</td>
      <td>-73.94190</td>
      <td>Private room</td>
      <td>150</td>
      <td>3</td>
      <td>0</td>
      <td>NaN</td>
      <td>0.00</td>
      <td>1</td>
      <td>365</td>
    </tr>
    <tr>
      <th>3</th>
      <td>3831</td>
      <td>Cozy Entire Floor of Brownstone</td>
      <td>4869</td>
      <td>LisaRoxanne</td>
      <td>Brooklyn</td>
      <td>Clinton Hill</td>
      <td>40.68514</td>
      <td>-73.95976</td>
      <td>Entire home/apt</td>
      <td>89</td>
      <td>1</td>
      <td>270</td>
      <td>2019-07-05</td>
      <td>4.64</td>
      <td>1</td>
      <td>194</td>
    </tr>
    <tr>
      <th>4</th>
      <td>5022</td>
      <td>Entire Apt: Spacious Studio/Loft by central park</td>
      <td>7192</td>
      <td>Laura</td>
      <td>Manhattan</td>
      <td>East Harlem</td>
      <td>40.79851</td>
      <td>-73.94399</td>
      <td>Entire home/apt</td>
      <td>80</td>
      <td>10</td>
      <td>9</td>
      <td>2018-11-19</td>
      <td>0.10</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 48895 entries, 0 to 48894
    Data columns (total 16 columns):
     #   Column                          Non-Null Count  Dtype  
    ---  ------                          --------------  -----  
     0   id                              48895 non-null  int64  
     1   name                            48879 non-null  object 
     2   host_id                         48895 non-null  int64  
     3   host_name                       48874 non-null  object 
     4   neighbourhood_group             48895 non-null  object 
     5   neighbourhood                   48895 non-null  object 
     6   latitude                        48895 non-null  float64
     7   longitude                       48895 non-null  float64
     8   room_type                       48895 non-null  object 
     9   price                           48895 non-null  int64  
     10  minimum_nights                  48895 non-null  int64  
     11  number_of_reviews               48895 non-null  int64  
     12  last_review                     38843 non-null  object 
     13  reviews_per_month               48895 non-null  float64
     14  calculated_host_listings_count  48895 non-null  int64  
     15  availability_365                48895 non-null  int64  
    dtypes: float64(3), int64(7), object(6)
    memory usage: 6.0+ MB
    


```python
available_room=df.groupby(['neighbourhood_group'],as_index=False)['availability_365'].mean().sort_values(['availability_365'],ascending=True)
```


```python
available_room
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>neighbourhood_group</th>
      <th>availability_365</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1</th>
      <td>Brooklyn</td>
      <td>100.232292</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Manhattan</td>
      <td>111.979410</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Queens</td>
      <td>144.451818</td>
    </tr>
    <tr>
      <th>0</th>
      <td>Bronx</td>
      <td>165.758937</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Staten Island</td>
      <td>199.678284</td>
    </tr>
  </tbody>
</table>
</div>




```python
sns.barplot(x='neighbourhood_group',y='availability_365',data=available_room)
plt.xlabel('neighbourhood_group',fontweight='bold')
plt.ylabel('availability_365',fontweight='bold')
plt.show()
```


    
![png](output_36_0.png)
    



```python
#less room availability in brooklyn and greater room availability in Staten island compare to other.less room availability means most of the room booking.
```
